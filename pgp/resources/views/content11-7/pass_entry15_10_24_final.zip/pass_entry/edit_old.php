@extends('layouts/contentNavbarLayout')

@section('title', 'Vertical Layouts - Forms')

@section('content')
<div class="row   page-hed">
    <div class="col-12">
        <h4 class=""><span class="text-muted fw-light">Pass/</span>Pass Entry</h4>
    </div>
</div>

<style>
/* btn style */
.btn-right {
    float: right;
}

.password-container {
    position: relative;
}

.input-wrapper {
    position: relative;
}

.input-wrapper .form-control {
    padding-right: 30px;
}

.input-wrapper .toggle-password {
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    cursor: pointer;
    color: #6c757d;
}

.font-weight-bold {
    font-weight: bold;
}
</style>

@php
$currentdate = date('Y-m-d');
$get_firm_reg_type =get_firm_reg_type();
$get_vech_type =get_vech_type();

$get_person_type = get_person_type();

$screen_unique_id=generateScreenUniqueId();
@endphp
<!-- Basic Layout -->
<div class="row">
    <div class="col-xl">
        <div class="card mb-4">
            <div class="card-body">
                <div id="academicYearForm">
                    <form id="pass_entry_form" action="{{ route('pass_entry.update', $passentrymain_list->id) }}"
                        method="POST">
                        @csrf
                        @method('PUT')
                        <div class="row mb-3 mt-2">
                            <div class="col-sm-2  ">
                                <input type="hidden" id="screen_unique_id" name="screen_unique_id"
                                    value="<?php echo $screen_unique_id;?>">
                                <label for="colFormLabelSm" class="col-form-label">Issue Center</label>
                            </div>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="issue_center" name="issue_center"
                                    value="{{ old('issue_center', $passentrymain_list->issue_center) }}" />
                            </div>
                        </div>

                        <div class="row mb-3 mt-2">
                            <div class="col-sm-2  ">
                                <label for="colFormLabelSm" class="col-form-label">Firms /Agent Name</label>
                            </div>
                            <div class="col-sm-4">
                                <!-- <select class="form-select" id="firms_agent" name="firms_agent">
                                <option value="">Select Agent Name</option>
                                <option value="ship_agent">Ship Agent</option>
                                <option value="customer_broker">Customer Broker</option>
                            </select> -->
                                <select class="form-select" id="firms_agent" name="firms_agent">
                                    <option value="">
                                        Select </option>
                                    @foreach ($firm_registration as $agent)
                                    <option value="{{ $agent->unique_id }}"
                                        {{ $passentrymain_list->firms_agent == $agent->unique_id ? 'selected' : '' }}>
                                        {{ $agent->firm_agent_name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-sm-2">
                                <label for="colFormLabelSm" class="col-form-label">Pass Type</label>
                            </div>
                            <div class="col-sm-4">
                                <select class="form-select" id="passType" name="passType" onchange="pass_type()">
                                    <!-- <option value="">Select Pass Type</option> -->
                                    <option value="vehicle"
                                        {{ old('passtype', $passentrymain_list->passtype) == 'vehicle' ? 'selected' : '' }}>
                                        Vehicle Pass
                                    </option>
                                    <option value="person"
                                        {{ old('passtype', $passentrymain_list->passtype) == 'person' ? 'selected' : '' }}>
                                        Person Pass
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3 mt-2">
                            <!-- style="display:none;" -->
                            <div class=" col-sm-2" id="vehicle_type_div1">
                                <label for=" colFormLabelSm" class="col-form-label">Vehicle Type</label>
                            </div>
                            <div class="col-sm-4" id="vehicle_type_div">
                                <!-- style="display:none;" -->
                                <!-- <select class="form-select" id="vectype" name="vectype" onchange="vech_type()">
                                <option value="">Select vectype</option>
                                <option value="equipment">Equipment vehicle</option>
                                <option value="heavy">Heavy Vechicle</option>
                                <option value="light">Light vehicle</option>
                            </select> -->
                                <select class="form-select" id="vectype" name="vectype" onchange="vech_type()">
                                    <option value="">
                                        Select </option>
                                    @foreach ($get_vech_type as $vech_type)
                                    <option value="{{$vech_type->unique_id}}">
                                        {{$vech_type->vehicle_type}}
                                    </option>
                                    @endforeach
                                </select>

                            </div>
                            <div class="col-sm-2" id="person_div" style="display:none;">
                                <label for="colFormLabelSm" class="col-form-label">Person Type</label>
                            </div>
                            <div class="col-sm-4" id="person_div1" style="display:none;">
                                <!-- <select class="form-select" id="persontype" name="persontype" onchange="person_type()">
                                <option value="">Select Person Type</option>
                                <option value="person">Person</option>
                                <option value="employee">Employee</option>
                                <option value="driver">Driver</option>
                                <option value="cleaner">Cleaner</option>
                            </select> -->
                                <select class="form-select" id="persontype" name="persontype" onchange="person_type()">
                                    <option value="">
                                        Select </option>
                                    @foreach ($get_person_type as $person_type)
                                    <option value="{{$person_type->unique_id}}">
                                        {{$person_type->person_type}}
                                    </option>
                                    @endforeach
                                </select>


                            </div>

                            <div class="col-sm-2" id="vehicle_div">
                                <!-- style="display:none;" -->
                                <label for="colFormLabelSm" class="col-form-label">Reg. Vehicle Number</label>
                            </div>
                            <div class="col-sm-4" id="vehicle_div1">
                                <!-- style="display:none;" -->
                                <input type="text" class="form-control" id="vec_reg_no" name="vec_reg_no"
                                    oninput="vehicle_data()"
                                    value="{{ old('vec_reg_no', $passentrymain_list->vec_reg_no) }}" />
                            </div>


                            <!-- id="get_adhaar" -->
                            <div class="col-sm-2" id="adhaar">
                                <!-- style="display:none;" -->
                                <label for="colFormLabelSm" class="col-form-label">Adhaar No.</label>
                            </div>
                            <!--  id="get_adhaar1" -->
                            <div class="col-sm-4" id="adhaar1">
                                <!-- style="display:none;" -->
                                <input type="text" class="form-control" id="adhaar_no" name="adhaar_no"
                                    oninput="person_data1()" />
                            </div>
                            <div id="person_driver" class="col-sm-2">
                                <!--  style="display:none;" -->
                                <label for="colFormLabelSm" class="col-form-label">Driving License No.</label>
                            </div>
                            <div id="person_driver1" class="col-sm-4">
                                <!-- style="display:none;" -->
                                <input type="text" class="form-control" id="driving_license" name="driving_license"
                                    oninput="person_data()" />
                            </div>

                        </div>

                        <div id="vehicle_details" style="display:none;">
                            <div class="row">

                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">Purpose of
                                        Cargo</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">Cargo 1</label>
                                </div>
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">Card Number</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">2422fe1111</label>
                                </div>
                                <div class="col-sm-2 ">
                                    <label for="colFormLabelSm" class="col-form-label">Type of Vehicle</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">Truck</label>
                                </div>
                            </div>
                            <div class="row">


                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">EIR Number</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">EIR0001</label>
                                </div>
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">Insurance Valid
                                        UPTO</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label ">02/08/2025</label>
                                </div>
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">FC Valid UPTO</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">15/02/2025</label>
                                </div>
                            </div>

                            <div class=" row ">

                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">PUC Valid UPTO</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">12/12/2024</label>
                                </div>
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">RC Attach</label>
                                </div>
                                <div class="col-sm-2">
                                    <img src="resources/views/content/person_registration/PDF.png" alt="PDF"
                                        style="width: 24px; height: 24px;">
                                </div>

                            </div>

                        </div>
                        <div id="person_details" style="display:none;">
                            <div class="row ">
                                <div class="col-sm-2 ">
                                    <label for="colFormLabelSm" class="col-form-label">Name</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">Dinesh</label>
                                </div>
                                <div class="col-sm-2 ">
                                    <label for="colFormLabelSm" class="col-form-label">Blood Group</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">A+</label>

                                </div>
                                <div class="col-sm-2">
                                    <label for="colFormLabelSm" class="col-form-label">Designation</label>
                                </div>
                                <div class="col-sm-2">
                                    <label id="person" style="display:none"
                                        class="col-sm-12 col-form-label">Person</label>
                                    <label id="driver" style="display:none"
                                        class="col-sm-12 col-form-label  ">Person</label>
                                </div>

                            </div>
                            <div class="row ">
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">Card Number</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">2422fe1111</label>
                                </div>
                                <div class=" col-sm-2 ">
                                    <label for=" colFormLabelSm" class="col-form-label">Nationality</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">Indian</label>
                                </div>
                                <div class="col-sm-2">
                                    <label for="colFormLabelSm" class="col-form-label">Country</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label">India</label>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">VISA No.</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">12345678764325</label>

                                </div>
                                <div class="col-sm-2 ">
                                    <label for="colFormLabelSm" class="col-form-label">Mobile</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">9898989098</label>
                                </div>
                                <div class="col-sm-2">
                                    <label for="colFormLabelSm" class="col-form-label">E-Mail ID</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">dinesh@gmail.com</label>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">Type of ID Proof</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">Adhaar Card</label>
                                </div>
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">ID Proof No.</label>
                                </div>
                                <div class="col-sm-2">
                                    <label class="col-sm-12 col-form-label  ">3446567511</label>
                                </div>


                            </div>

                            <div class="row">
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">ID Proof Attach</label>
                                </div>
                                <div class="col-sm-2">
                                    <img onclick="pdf()" target="_blank"
                                        src="resources/views/content/person_registration/PDF.png" alt="PDF"
                                        style="width: 24px; height: 24px;">

                                </div>
                                <div class="col-sm-2  ">
                                    <label for="colFormLabelSm" class="col-form-label">Photo</label>
                                </div>
                                <div class="col-sm-4">
                                    <img onclick="pdf()" target="_blank"
                                        src="resources/views/content/person_registration/PDF.png" alt="PDF"
                                        style="width: 24px; height: 24px;">
                                </div>

                            </div>
                        </div>
                        <div class="row mb-3 mt-2">
                            <!-- <div class="col-sm-2  ">
                            <label for="colFormLabelSm" class="col-form-label">Access Gate</label>
                        </div>
                        <div class="col-sm-4">
                            <select class="form-select">
                                <option value="">Select Access Gate</option>
                                <option value="1">Inside/Outside</option>
                                <option value="2">Custom Bound Area</option>
                                <option value="3">Zone A & B</option>
                            </select>
                        </div> -->

                            <div class="col-sm-2  ">
                                <label for="colFormLabelSm" class="col-form-label">Access Area</label>
                            </div>
                            <div class="col-sm-4">
                                <select class="form-select me-2" name="access_area" id="access_area">
                                    <option value="">Select</option>
                                    <option value="SBW"
                                        {{ old('access_area', $passentrymain_list->access_area) == 'SBW' ? 'selected' : '' }}>
                                        SBW
                                    </option>
                                    <option value="NBW"
                                        {{ old('access_area', $passentrymain_list->access_area) == 'NBW' ? 'selected' : '' }}>
                                        NBW
                                    </option>
                                    <option value="NCB"
                                        {{ old('access_area', $passentrymain_list->access_area) == 'NCB' ? 'selected' : '' }}>
                                        NCB
                                    </option>
                                    <option value="zone_b"
                                        {{ old('access_area', $passentrymain_list->access_area) == 'zone_b' ? 'selected' : '' }}>
                                        Zone B
                                    </option>
                                </select>
                            </div>



                            <div class="col-sm-2" id="vehicle_type_no1">
                                <!-- style="display:none;" -->
                                <label for="colFormLabelSm" class="col-form-label">Vehicle No.</label>
                            </div>
                            <div class="col-sm-4" id="vehicle_type_no">
                                <!-- style=" display:none;" -->
                                <input type="text" class="form-control" id="vech_no" name="vech_no" />
                            </div>
                            <div class="col-sm-2 " id="pass_weight_div">
                                <!-- style="display:none" -->
                                <label for="colFormLabelSm" class="col-form-label">Passing Weight</label>
                            </div>
                            <div class="col-sm-4" id="pass_weight_div1">
                                <!--  style="display:none" -->
                                <input type="text" class="form-control" id="pass_weight" name="pass_weight"
                                    value="{{ old('pass_weight', $passentrymain_list->pass_weight) }}" />
                            </div>
                        </div>
                        <div class="row mb-3 mt-2">
                            <div id="upload" class="col-sm-2"> <label for="photo">Photo</label></div>
                            <div class="col-sm-4">
                                <input type="file" class="form-control" id="cover_letter" name="cover_letter"
                                    value="{{ old('cover_letter', $passentrymain_list->cover_letter) }}" />
                            </div>
                        </div>
                        <hr>

                        <div class="row mb-3 mt-2">
                            <div class="col-sm-2  ">
                                <label for="colFormLabelSm" class="col-form-label">Type of Pass</label>
                            </div>
                            <!-- </div> -->
                            <div class="col-sm-2">
                                <select class="form-select me-2" name="type_of_pass" id="type_of_pass"
                                    Onchange="get_vec_pass()">
                                    <option value="">Select</option>
                                    <option value="day">Day</option>
                                    <option value="weekly">Weekly</option>
                                    <option value="monthly">Monthly</option>
                                    <option value="halfyearly">Half Yearly</option>
                                    <option value="yearly">Yearly</option>
                                </select>
                            </div>
                            <div class="col-sm-2  ">
                                <label for="colFormLabelSm" class="col-form-label">From Date</label>
                            </div>
                            <div class="col-sm-2">
                                <input type="date" class="form-control" id="from_date" name="from_date"
                                    value="<?php echo $currentdate;?>" />
                            </div>
                            <div class="col-sm-2  ">
                                <label for="colFormLabelSm" class="col-form-label">To Date</label>
                            </div>
                            <div class="col-sm-2">
                                <!-- <input type="date" class="form-control" id="to_date" name="to_date" /> -->
                                <input type="datetime-local" class="form-control" id="to_date" name="to_date" />
                            </div>
                            <!-- style="display:none" -->
                            <input type="hidden" id="date_display" name="date_display">
                            <!-- Element to display formatted date -->
                        </div>

                        <!-- <div class="row mb-3 mt-2">


                    </div> -->

                        <div class="row mb-3 mt-2">

                            <div class=" col-sm-2 ">
                                <label for=" colFormLabelSm" class="col-form-label">Period</label>
                            </div>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="no_of_days" name="no_of_days"
                                    oninput="calculateToDate()" />
                            </div>
                            <div class="col-sm-2">
                                <label for="amount" class="col-form-label">Amount</label>
                            </div>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="amount" name="amount"
                                    oninput="calculateamount()" />
                            </div>
                        </div>
                        <div class="row mb-3 mt-2 justify-content-end">
                            <div class="col-sm-2 text-end">
                                <label for="sgst" class="col-form-label">SGST</label>
                            </div>
                            <div class="col-sm-2 text-end">
                                <label class="col-form-label" id="sgstLabel"></label>
                                <input type="hidden" class="form-control" id="sgst" name="sgst" />
                            </div>
                        </div>
                        <div class="row mb-3 mt-2 justify-content-end">
                            <div class="col-sm-2 text-end">
                                <label for="cgst" class="col-form-label">CGST</label>
                            </div>
                            <div class="col-sm-2 text-end">
                                <label class="col-form-label" id="cgstLabel"></label>
                                <input type="hidden" class="form-control" id="cgst" name="cgst" />
                            </div>
                        </div>
                        <div class="row mb-3 mt-2 justify-content-end">
                            <div class="col-sm-2 text-end">
                                <label for="gross_amount" class="col-form-label">Total Gross Amount</label>
                            </div>

                            <div class="col-sm-2 text-end">
                                <label class="col-form-label" id="gross_amountlabel" name="gross_amountlabel"></label>
                                <input type="hidden" class="form-control" id="gross_amount" name="gross_amount" />
                            </div>
                        </div>
                        <!-- </div> -->
                        <!-- </form> -->


                        <!-- <div class="row mb-2 mt-2 justify-content-center"> -->
                        <!-- <div class="col-sm-4 text-center ">
                        <label for="gross_amount" class="col-form-label">Total Gross Amount</label>
                    </div>
                    <div class="col-sm-4  text-center">
                        <label class="col-form-label" id="gross_amountlabel" name="gross_amountlabel"></label>
                        <input type="hidden" class="form-control" id="gross_amount" name="gross_amount" />
      div           </div> -->
                        <!-- </div> -->
                        <div class="justify-content-center submit_sublist" style="float: right;">
                            <button id="openTableButton submit_sublist" onclick="sublist_proof(event)"
                                class="btn btn-primary">Add</button>
                        </div>

                        <br><br>
                        <div id="dataTableContainer" class="table-responsive ">
                            <table id="sublist" class="table table-striped table-bordered" style="width:100%">
                                <thead class="thead-light">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Agent Name.</th>
                                        <th>Pass Type.</th>
                                        <th>No of Days</th>
                                        <th>From Date</th>
                                        <th>To Date</th>
                                        <th>gross Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                @foreach ($sublist_entries as $sublist_entrie)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $sublist_entrie->agent_name }}</td>
                                    <td>{{ $sublist_entrie->type_of_pass }}</td>
                                    <td>{{ $sublist_entrie->no_of_days }}</td>
                                    <td>{{ $sublist_entrie->from_date }}</td>
                                    <td>{{ $sublist_entrie->to_date }}</td>
                                    <td>{{ $sublist_entrie->gross_amount }}</td>
                                    <td>
                                        <a onclick="deletepass({{ $sublist_entrie->id }})"><i
                                                class="fas fa-trash-alt"></i>
                                    </td>

                                </tr>
                                @endforeach
                                <tbody>
                                </tbody>
                            </table>
                        </div>

                        <div class="row mb-3 mt-2">
                            <div class="col-sm-3">
                                <label for=" colFormLabelSm" class="col-form-label">Total Pass Amount</label>
                            </div>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="pass_amount" name="pass_amount"
                                    value="{{ old('pass_amount', $totalGrossAmount) }}" />
                            </div>
                            <!-- <div class="col-sm-4">
                            <button type="button" id="openTableButton" class="btn btn-primary"
                                onclick="window.location.href='{{ url('/payment_option')}}'">Payment</button>
                        </div> -->

                        </div>

                        <div class="btn-float">
                            <button type="button" class="btn btn-danger"
                                onclick="window.location.href='{{ url('/pass_entry')}}'">Cancel</button>
                            <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
                            <!-- <button type="submit"
                            class="btn btn-primary">{{ isset($acc_year) ? 'Update' : 'Submit' }}</button> -->
                            <button type="button" class="btn btn-primary" onclick="submit_save()">Payment Go to
                                Save</button>

                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>


<script src="{{ asset('public/assets/js/jquery-3.7.1.js') }}"></script>
<script src="{{ asset('public/assets/js/common.js') }}"></script>
<script src="{{ asset('public/assets/js/sweet_alert.js') }}"></script>

<!-- DataTables CSS -->
<!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css"> -->

<!-- jQuery -->
<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->

<!-- DataTables JS -->


<script>
// Delete center function

function deletepass(id) {
    alert();
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '{{ route("pass_sublist.delete", ":id") }}'.replace(":id",
                    id), // Correct URL

                method: 'DELETE',
                data: {
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    if (response.success) {
                        sweetalert('success_delete');

                        // Swal.fire('Deleted!', response.message, 'success').then(() => {
                        //     window.location.reload();
                        // });
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function(xhr) {
                    Swal.fire('Error!', 'Something went wrong.', 'error');
                }
            });

        }
    });
}

function pass_type() {

    const passType = document.getElementById('passType').value;

    // Hide both vehicle and person divs initially
    document.getElementById("vehicle_div").style.display = "none";
    document.getElementById("vehicle_div1").style.display = "none";
    document.getElementById("person_div").style.display = "none";
    document.getElementById("vehicle_type_div").style.display = "none";
    document.getElementById("vehicle_type_div1").style.display = "none";
    document.getElementById("pass_weight_div").style.display = "none";
    document.getElementById("vehicle_type_no").style.display = "none";
    document.getElementById("vehicle_type_no1").style.display = "none";

    // document.getElementById("person_div1").style.display = "none";

    // Show the appropriate div based on selected option
    if (passType === 'vehicle') {

        document.getElementById('persontype').value = '';
        // document.getElementById('adhaar_no').value = '';
        // document.getElementById('person_details').value = '';

        // document.getElementById("vehicle_div").style.display = "block";
        // document.getElementById("vehicle_div1").style.display = "block";
        document.getElementById("vehicle_type_div").style.display = "block";
        document.getElementById("vehicle_type_div1").style.display = "block";
        document.getElementById("person_div").style.display = "none";
        document.getElementById("person_div1").style.display = "none";
        document.getElementById("vehicle_type_no").style.display = "none";
        document.getElementById("vehicle_type_no1").style.display = "none";


        document.getElementById("person_driver").style.display = "none";
        document.getElementById("person_driver1").style.display = "none";

        document.getElementById("adhaar").style.display = "none";

        document.getElementById("adhaar1").style.display = "none";

        document.getElementById("pass_weight_div").style.display = "block";
        document.getElementById("pass_weight_div1").style.display = "block";
        // document.getElementById("person_details").style.display = "none";
        // document.getElementById("vehicle_details").style.display = "block";

        // document.getElementById("vehicle_details").style.display = "block";
        // document.getElementById('adhaar').value = '';
        // document.getElementById("vec_vec_reg_no").value = "";

        // document.getElementById("get_adhaar").style.display = "none";
        // document.getElementById("get_adhaar1").style.display = "none";



    } else if (passType === 'person') {
        document.getElementById('vectype').value = '';
        // document.getElementById('vec_reg_no').value = '';
        // document.getElementById('vehicle_details').value = '';

        document.getElementById("person_div").style.display = "block";
        document.getElementById("person_div1").style.display = "block";
        document.getElementById("vehicle_type_no").style.display = "block";
        document.getElementById("vehicle_type_no1").style.display = "block";
        // document.getElementById("get_adhaar").style.display = "block";
        // document.getElementById("get_adhaar1").style.display = "block";

        document.getElementById("vehicle_type_no").style.display = "block";
        document.getElementById("vehicle_type_no1").style.display = "block";
        document.getElementById("pass_weight_div").style.display = "none";
        document.getElementById("pass_weight_div1").style.display = "none";
        document.getElementById("vehicle_div").style.display = "none";
        document.getElementById("vehicle_div1").style.display = "none";


    } else {
        document.getElementById("person_div").style.display = "none";
        document.getElementById("person_div1").style.display = "none";
        document.getElementById("vehicle_type_no").style.display = "none";
        document.getElementById("vehicle_type_no1").style.display = "none";
        // document.getElementById("get_adhaar").style.display = "block";
        // document.getElementById("get_adhaar1").style.display = "block";

        document.getElementById("vehicle_type_no").style.display = "none";
        document.getElementById("vehicle_type_no1").style.display = "none";
        document.getElementById("pass_weight_div").style.display = "none";
        document.getElementById("pass_weight_div1").style.display = "none";
        // document.getElementById("vehicle_details").style.display = "none";
        // document.getElementById("person_details").style.display = "none";
    }


}


function person_type() {
    const person_type = document.getElementById('persontype').value;
    // alert(person_type);

    // Hide both vehicle and person divs initially
    document.getElementById("person_driver").style.display = "none";
    document.getElementById("person_driver1").style.display = "none";
    // aaadhar
    document.getElementById("adhaar").style.display = "none";

    document.getElementById("adhaar1").style.display = "none";


    // Show the appropriate div based on selected option
    if (person_type === '66fe76256d3a792499') {
        document.getElementById("person_driver").style.display = "block";
        document.getElementById("person_driver1").style.display = "block";
    } else {
        document.getElementById("adhaar").style.display = "block";
        document.getElementById("adhaar1").style.display = "block";

    }
}



// new changes
function vech_type() {
    const vech_type = document.getElementById('vectype').value;
    // alert(vech_type);

    // Hide both vehicle and person divs initially
    document.getElementById("vehicle_div").style.display = "none";
    document.getElementById("vehicle_div1").style.display = "none";
    // vehicle_div1

    document.getElementById("vehicle_div1").style.display = "none";

    document.getElementById("vehicle_div1").style.display = "none";


    // Show the appropriate div based on selected option
    if (vech_type != "") {
        document.getElementById("vehicle_div").style.display = "block";
        document.getElementById("vehicle_div").style.display = "block";
        document.getElementById("vehicle_div1").style.display = "block";

        document.getElementById("vehicle_div1").style.display = "block";

    }


}

// end

function vehicle_data() {
    // vehicle_details
    const vehicle_validate = document.getElementById('vec_reg_no').value;
    // alert(vehicle_validate);

    document.getElementById("vehicle_details").style.display = "none";

    if (vehicle_validate) {
        document.getElementById('adhaar_no').value = '';
        // document.getElementById('persontype').value = '';
        // document.getElementById("adhaar").style.display = "none";
        document.getElementById("person_details").style.display = "none";
        document.getElementById("vehicle_details").style.display = "block";
    }

}

function person_data() {
    const person_validate = document.getElementById('driving_license').value;
    // alert(person_validate);
    document.getElementById("person_details").style.display = "none";
    if (person_validate) {
        document.getElementById('vec_reg_no').value = '';

        document.getElementById("vehicle_details").style.display = "none";
        document.getElementById("person_details").style.display = "block";
        document.getElementById("driver").style.display = "block";

    }
}


function person_data1() {
    const person_validate = document.getElementById('adhaar_no').value;
    // alert(person_validate);
    document.getElementById("person_details").style.display = "none";
    if (person_validate != '') {
        document.getElementById('vec_reg_no').value = '';

        // document.getElementById('vec_reg_no').value = '';

        document.getElementById("vehicle_details").style.display = "none";
        document.getElementById("person_details").style.display = "block";
        // document.getElementById("person").style.display = "block";
        document.getElementById("adhaar").style.display = "block";

        document.getElementById("adhaar1").style.display = "block";


    }

}



// nw changes sublist


//document details
function sublist_proof(event) {
    // alert();

    event.preventDefault()
    // Get form values
    var firms_agent = $('#firms_agent').val();
    var type_of_pass = $('#type_of_pass').val();
    // alert(type_of_pass);
    var no_of_days = $('#no_of_days').val();
    var from_date = $('#from_date').val();
    var to_date = $('#date_display').val();
    // alert(to_date);
    var amount = $('#amount').val();
    var sgst = $('#sgst').val();
    // alert(sgst);
    var cgst = $('#cgst').val();
    // alert(cgst);
    var gross_amount = $('#gross_amount').val();
    var screen_unique_id = $('#screen_unique_id').val();
    // var pass_amount = $('#pass_amount').val();

    // alert(screen_unique_id);

    var s_no = 1;

    var s_nos = s_no++;



    // Create FormData object to handle file uploads
    var formData = new FormData();
    formData.append('firms_agent', firms_agent);
    formData.append('type_of_pass', type_of_pass);
    formData.append('no_of_days', no_of_days);
    formData.append('from_date', from_date);
    formData.append('to_date', to_date);
    formData.append('amount', amount);
    formData.append('screen_unique_id', screen_unique_id); // Include screen_unique_id
    formData.append('gross_amount', gross_amount);
    formData.append('sgst', sgst);
    formData.append('cgst', cgst);
    // formData.append('pass_amount', pass_amount);
    formData.append('_token', '{{csrf_token()}}'); // Add CSRF token for security


    // AJAX request to submit form data
    $.ajax({
        type: "POST",
        url: '{{route("pass_sublist.create")}}', // Update the route
        data: formData,
        contentType: false, // Important for file upload
        processData: false, // Prevent jQuery from processing the data


        success: function(response) {

            // var file_name = response.attached_proof;
            // var proof_type = response.proof_type;
            var newRow = `
            <tr>
                <td>${s_nos}</td>
                <td>${firms_agent}</td>
                <td>${type_of_pass}</td>
                <td>${no_of_days}</td>
                <td>${from_date}</td>
                <td>${to_date}</td>
                <td>${gross_amount}</td>
                 <td>
                        <button class="btn btn-danger btn-sm" onclick="deleteProof(${response.id})">Delete</button>
            </td>
            
            </tr>
        `;

            // Append the new row to the tbody of the #sublist table
            $('#sublist tbody').append(newRow);
            // Update the pass_amount input with the total gross amount
            $('#pass_amount').val(response.pass_amount);
            // Optionally, reset form fields after successful submission
            // $('#firms_agent').val('');
            $('#type_of_pass').val('');
            $('#no_of_days').val('');
            // $('#from_date').val('');
            $('#to_date').val('');
            $('#amount').val('');
            $('#sgst').val('');
            $('#cgst').val('');
            $('#gross_amount').val('');
        },
        error: function(xhr) {
            console.log(xhr.responseText); // Log any errors for debugging
        }
    });
}


// end


//main list store function
function submit_save() {
    // alert();

    var screen_unique_id = $('#screen_unique_id').val(); // Get the unique ID from the input field
    // alert(screen_unique_id);

    // Create a new FormData object
    var formData = new FormData();

    // Append form fields to the FormData object
    formData.append('screen_unique_id', screen_unique_id); // Include screen_unique_id in the FormData
    formData.append('issue_center', $('#issue_center').val());
    formData.append('firms_agent', $('#firms_agent').val());
    formData.append('vectype', $('#vectype').val());
    formData.append('passType', $('#passType').val());
    formData.append('persontype', $('#persontype').val());
    formData.append('vec_reg_no', $('#vec_reg_no').val());
    formData.append('driving_license', $('#driving_license').val());
    formData.append('access_area', $('#access_area').val());
    formData.append('adhaar_no', $('#adhaar_no').val());
    formData.append('vech_no', $('#vech_no').val());
    formData.append('pass_amount', $('#pass_amount').val());
    formData.append('pass_weight', $('#pass_weight').val());
    formData.append('_token', '{{csrf_token()}}');
    // Get the file from the input and append it to the FormData object
    var cover_letter = document.getElementById('cover_letter').files[0];
    if (cover_letter) {
        formData.append('cover_letter', cover_letter);
    }

    // Make the AJAX request using FormData
    $.ajax({
        type: "POST",
        url: "{{route('pass_entry.store')}}",
        data: formData,
        contentType: false,
        processData: false,
        success: function(response) {
            console.log(response); // Log the whole response for debugging
            if (response.screen_unique_id) {
                $('#screen_unique_id').val(response.screen_unique_id);
                // alert('Unique ID: ' + response.screen_unique_id);
                sweetalert("create");


                window.location.href = "{{ route('pass_entry') }}";

            }
        },
        error: function(xhr) {
            console.error(xhr.responseText); // Log the error response
            alert('An error occurred: ' + xhr.responseText);
        }
    });
}

// main list end
//-------------------------image and pdf view download function------///////

function imageViews(file_name, cover_letter) {
    // Split the file names by commas (in case there are multiple)
    var fileNames = file_name.split(',');

    // Base directory wher your files are stored
    var pass_entry = 'public/uploads/pass_entry';
    // var licenceDirectory = 'public/uploads/person_registration/licence/';


    fileNames.forEach(function(fileName) {
        // Get the file extension
        var cFileName = fileName.split('.');
        var fileExtension = cFileName[cFileName.length - 1].toLowerCase();
        var filePath = `${baseDirectory}${fileName}`; // Construct the full path



        var baseDirectory;

        // if (proof_type == 'aadhaar') {
        baseDirectory = pass_entry;
        // } else if (proof_type == 'driving_licence') {
        //     baseDirectory = licenceDirectory;

        // }

        var filePath = `${baseDirectory}${fileName}`;

        if (fileExtension === 'jpg' || fileExtension === 'png' || fileExtension === 'jpeg') {
            // Open image in a new tab
            window.open(filePath, '_blank');
        } else if (fileExtension === 'pdf') {

            window.open(filePath, '_blank');
            // Trigger download for PDF
            // const link = document.createElement('a');
            // link.href = filePath;
            // link.download = fileName; // Trigger download
            // link.click();
        } else if (fileExtension === 'xls' || fileExtension === 'xlsx') {
            // Trigger Excel download
            const link = document.createElement('a');
            link.href = filePath;
            link.download = fileName;
            link.click();
        } else if (fileExtension === 'txt' || fileExtension === 'docx' || fileExtension === 'doc') {
            // Trigger download for text or Word files
            const link = document.createElement('a');
            link.href = filePath;
            link.download = fileName;
            link.click();
        }
    });
}


// const type_of_pass = document.getElementById('type_of_pass').value;
// alert(type_of_pass);
// const from_date = document.getElementById('from_date').value; // expected format: dd-mm-yyyy
// const no_of_days = parseInt(document.getElementById('no_of_days').value); // convert to integer

// if (type_of_pass == "day") {
//     // Process for day pass
// } else if (type_of_pass == "weekly") {
//     // Process for weekly pass
// } else if (type_of_pass == "monthly") {
//     // Process for monthly pass
// } else if (type_of_pass == "yearly") {
//     // Process for yearly pass
// }


// // Function to calculate the "to date"
// function calculateToDate() {
//     alert(from_date);
//     const from_date = document.getElementById('from_date').value;
//     const no_of_days = document.getElementById('no_of_days').value;
//     const to_date = document.getElementById('to_date').value;
//     // $po_date = $value['po_date'];
//     // $delivery_due_dates = $value['delivery_due_dates'];
//     const from_date = DateTime::createFromFormat('d-m-Y', from_date);
//     const from_date - > modify('+'.no_of_days.
//         ' days');
//     const todate = from_date - > format('d-m-Y');
//     alert(todate);

//     // $value['delivery_due_dates']=   $resultDate
//     // for red colur date display
//     // $currentDate = new DateTime();

// }
// window.onload = function() {
//     calculateToDate();
// };
// function calculateToDate() {
//     const fromDateInput = document.getElementById('from_date').value;
//     const noOfDays = parseInt(document.getElementById('no_of_days').value, 10);

//     // Convert the from date to a JavaScript Date object
//     const fromDate = new Date(fromDateInput.split('-').reverse().join('-'));

//     // Add the number of days
//     fromDate.setDate(fromDate.getDate() + noOfDays);

//     // Format the to date back to 'd-m-Y'
//     const day = String(fromDate.getDate()).padStart(2, '0');
//     const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
//     const year = fromDate.getFullYear();

//     const toDate = `${day}-${month}-${year}`;

//     // alert(toDate);
// }

// window.onload = function() {
//     document.getElementById('calculate_button').onclick = calculateToDate;
// };

// ne change

function calculateamount() {
    const amount = parseFloat(document.getElementById('amount').value);
    // const amount = 1000; // Taxable amount
    const gstRate = 18; // GST rate in percentage

    // Calculate total tax
    const totalTax = amount * (gstRate / 100);

    // Calculate CGST and SGST (both are half of the total tax)
    const sgstAmount = totalTax / 2;
    const cgstAmount = totalTax / 2;



    // Update the HTML elements
    document.getElementById('sgstLabel').textContent = `₹${sgstAmount.toFixed(2)}`;
    document.getElementById('sgst').value = sgstAmount.toFixed(2);
    document.getElementById('cgstLabel').textContent = `₹${cgstAmount.toFixed(2)}`;
    document.getElementById('cgst').value = cgstAmount.toFixed(2);

    const gross_amount = amount + sgstAmount + cgstAmount;
    document.getElementById('gross_amountlabel').textContent = `₹${gross_amount.toFixed(2)}`;
    document.getElementById('gross_amount').value =
        gross_amount.toFixed(2);

}





// function calculateToDate() {
//     const fromDateInput = document.getElementById('from_date').value;
//     const noOfDays = parseInt(document.getElementById('no_of_days').value, 10);

//     // Convert the from date to a JavaScript Date object
//     const fromDate = new Date(fromDateInput.split('-').reverse().join('-'));

//     // Add the number of days
//     fromDate.setDate(fromDate.getDate() + noOfDays);

//     // Format the to date for datetime-local
//     const year = fromDate.getFullYear();
//     const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
//     const day = String(fromDate.getDate()).padStart(2, '0');
//     const hours = String(fromDate.getHours()).padStart(2, '0');
//     const minutes = String(fromDate.getMinutes()).padStart(2, '0');

//     // Combine into the required format
//     const toDate = `${year}-${month}-${day}T${hours}:${minutes}`;

//     // Set the value of the to_date input
//     document.getElementById('to_date').value = toDate;

//     alert(toDate); // Optional: show the alert
// }

// window.onload = function() {
//     document.getElementById('calculate_button').onclick = calculateToDate;
// };

// function calculateToDate() {
//     const fromDateInput = document.getElementById('from_date').value;
//     alert(fromDateInput);
//     const noOfDays = parseInt(document.getElementById('no_of_days').value, 10);

//     // Validate the input format for YYYY-MM-DD
//     if (!/^\d{4}-\d{2}-\d{2}$/.test(fromDateInput)) {
//         alert("Please enter the date in YYYY-MM-DD format.");
//         return;
//     }

//     // Create a new Date object directly from the input
//     const fromDate = new Date(fromDateInput);

//     // Check if the date is valid
//     if (isNaN(fromDate.getTime())) {
//         alert("Invalid date. Please check the input.");
//         return;
//     }

//     // Add the number of days
//     fromDate.setDate(fromDate.getDate() + noOfDays);

//     // Format the to date for datetime-local
//     const year = fromDate.getFullYear();
//     const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
//     const day = String(fromDate.getDate()).padStart(2, '0');

//     // Combine into the required format for datetime-local
//     const toDate = `${year}-${month}-${day}T00:00`; // Set time to 00:00

//     // Set the value of the to_date input
//     document.getElementById('to_date').value = toDate;

//     // alert(todate1); // Optional: show the alert
// }

// window.onload = function() {
//     document.getElementById('calculate_button').onclick = calculateToDate;
// };
// function calculateToDate() {
//     const fromDateInput = document.getElementById('from_date').value;
//     const noOfDays = parseInt(document.getElementById('no_of_days').value, 10);

//     // Validate the input format for YYYY-MM-DD
//     if (!/^\d{4}-\d{2}-\d{2}$/.test(fromDateInput)) {
//         alert("Please enter the date in YYYY-MM-DD format.");
//         return;
//     }

//     // Create a new Date object directly from the input
//     const fromDate = new Date(fromDateInput);

//     // Check if the date is valid
//     if (isNaN(fromDate.getTime())) {
//         alert("Invalid date. Please check the input.");
//         return;
//     }

//     // Add the number of days
//     fromDate.setDate(fromDate.getDate() + noOfDays);

//     // Format the to date for datetime-local
//     const year = fromDate.getFullYear();
//     const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
//     const day = String(fromDate.getDate()).padStart(2, '0');
//     const hours = String(fromDate.getHours()).padStart(2, '0');
//     const minutes = String(fromDate.getMinutes()).padStart(2, '0');

//     // Combine into the required format for datetime-local
//     const toDate = `${year}-${month}-${day}T${hours}:${minutes}`; // Keep current time

//     // Set the value of the to_date input
//     document.getElementById('to_date').value = toDate;

//     alert(toDate); // Optional: show the alert
// }

// window.onload = function() {
//     document.getElementById('calculate_button').onclick = calculateToDate;
// };
function calculateToDate() {
    const fromDateInput = document.getElementById('from_date').value;

    const noOfDays = parseInt(document.getElementById('no_of_days').value, 10);
    const type_of_pass = document.getElementById('type_of_pass').value;
    // alert(type_of_pass);


    if (type_of_pass == "day") {
        // Validate the input format for YYYY-MM-DD
        // Get the number of days from input
        const noOfDays = parseInt(document.getElementById('no_of_days').value, 10) || 0; // Default to 0 if empty

        // Get the date input from the user
        let fromDateInput = document.getElementById('from_date').value;

        // Validate the input format for YYYY-MM-DD
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fromDateInput)) {
            alert("Please enter the date in YYYY-MM-DD format.");
            return;
        }

        // Create a new Date object directly from the input
        const fromDate = new Date(fromDateInput);

        // Check if the date is valid
        if (isNaN(fromDate.getTime())) {
            alert("Invalid date. Please check the input.");
            return;
        }

        // Use the current time for hours and minutes
        const currentTime = new Date();
        fromDate.setHours(currentTime.getHours());
        fromDate.setMinutes(currentTime.getMinutes());

        // Add the number of days
        fromDate.setDate(fromDate.getDate() + noOfDays);

        // Format the date for storage (datetime-local)
        const year = fromDate.getFullYear();
        const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const day = String(fromDate.getDate()).padStart(2, '0');
        const hours = String(fromDate.getHours()).padStart(2, '0');
        const minutes = String(fromDate.getMinutes()).padStart(2, '0');

        // Combine for datetime-local storage
        const toDateStorage = `${year}-${month}-${day}T${hours}:${minutes}`;

        // Determine AM/PM format for display
        let displayHours = fromDate.getHours();
        const ampm = displayHours >= 12 ? 'PM' : 'AM';
        displayHours = displayHours % 12; // Convert to 12-hour format
        displayHours = displayHours ? String(displayHours).padStart(2, '0') : '12'; // Display '12' instead of '0'

        // Combine for display
        const toDateDisplay = `${year}-${month}-${day} ${displayHours}:${minutes} ${ampm}`;

        // Set the value of the to_date input for storage
        document.getElementById('to_date').value = toDateStorage;

        // Append the formatted date to the date_display input
        const displayElement = document.getElementById('date_display'); // Ensure this element exists in your HTML
        displayElement.value = toDateDisplay; // Use textContent to display the date

        // Optionally alert the formatted date for user visibility
        // alert(toDateDisplay); // Uncomment if you want to show an alert


    } else if (type_of_pass == "weekly") {

        // Get the number of weeks from input
        const noOfWeeks = parseInt(document.getElementById('no_of_days').value, 10) || 0; // Default to 0 if empty

        // Get the date input from the user
        let fromDateInput = document.getElementById('from_date').value;

        // Validate the input format for YYYY-MM-DD
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fromDateInput)) {
            alert("Please enter the date in YYYY-MM-DD format.");
            return;
        }

        // Create a new Date object directly from the input
        const fromDate = new Date(fromDateInput);

        // Check if the date is valid
        if (isNaN(fromDate.getTime())) {
            alert("Invalid date. Please check the input.");
            return;
        }

        // Use the current time for hours and minutes
        const currentTime = new Date();
        fromDate.setHours(currentTime.getHours());
        fromDate.setMinutes(currentTime.getMinutes());

        // Add the number of weeks (7 days per week)
        fromDate.setDate(fromDate.getDate() + (noOfWeeks * 7));

        // Format the date for storage (datetime-local)
        const year = fromDate.getFullYear();
        const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const day = String(fromDate.getDate()).padStart(2, '0');
        const hours = String(fromDate.getHours()).padStart(2, '0');
        const minutes = String(fromDate.getMinutes()).padStart(2, '0');

        // Combine for datetime-local storage
        const toDateStorage = `${year}-${month}-${day}T${hours}:${minutes}`;

        // Determine AM/PM format for display
        let displayHours = fromDate.getHours();
        const ampm = displayHours >= 12 ? 'PM' : 'AM';
        displayHours = displayHours % 12; // Convert to 12-hour format
        displayHours = displayHours ? String(displayHours).padStart(2, '0') : '12'; // Display '12' instead of '0'

        // Combine for display (with AM/PM)
        const toDateDisplay = `${year}-${month}-${day} ${displayHours}:${minutes} ${ampm}`;

        // Set the value of the to_date input for storage
        document.getElementById('to_date').value = toDateStorage;

        // Append the formatted date to the date_display input
        const displayElement = document.getElementById('date_display'); // Ensure this element exists in your HTML
        displayElement.value = toDateDisplay; // Use textContent to display the date

        // Optionally alert the formatted date for user visibility
        // alert(toDateDisplay); // Uncomment if you want to show an alert
        // Alert or display the formatted date (for user visibility)
        // alert(toDateDisplay); // Show the alert for display
    } else if (type_of_pass == "monthly") {

        // Get the number of months from input
        const noOfMonths = parseInt(document.getElementById('no_of_days').value, 10) || 0; // Default to 0 if empty

        // Get the date input from the user
        let fromDateInput = document.getElementById('from_date').value;

        // Validate the input format for YYYY-MM-DD
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fromDateInput)) {
            alert("Please enter the date in YYYY-MM-DD format.");
            return;
        }

        // Create a new Date object directly from the input
        const fromDate = new Date(fromDateInput);

        // Check if the date is valid
        if (isNaN(fromDate.getTime())) {
            alert("Invalid date. Please check the input.");
            return;
        }

        // Use the current time for hours and minutes
        const currentTime = new Date();
        fromDate.setHours(currentTime.getHours());
        fromDate.setMinutes(currentTime.getMinutes());

        // Add the number of months
        fromDate.setMonth(fromDate.getMonth() + noOfMonths);

        // Format the date for storage (datetime-local)
        const year = fromDate.getFullYear();
        const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const day = String(fromDate.getDate()).padStart(2, '0');
        const hours = String(fromDate.getHours()).padStart(2, '0');
        const minutes = String(fromDate.getMinutes()).padStart(2, '0');

        // Combine for datetime-local storage
        const toDateStorage = `${year}-${month}-${day}T${hours}:${minutes}`;

        // Determine AM/PM format for display
        let displayHours = fromDate.getHours();
        const ampm = displayHours >= 12 ? 'PM' : 'AM';
        displayHours = displayHours % 12; // Convert to 12-hour format
        displayHours = displayHours ? String(displayHours).padStart(2, '0') : '12'; // Display '12' instead of '0'

        // Combine for display (with AM/PM)
        const toDateDisplay = `${year}-${month}-${day} ${displayHours}:${minutes} ${ampm}`;

        // Set the value of the to_date input for storage
        document.getElementById('to_date').value = toDateStorage;

        // Append the formatted date to the date_display input
        const displayElement = document.getElementById('date_display'); // Ensure this element exists in your HTML
        displayElement.value = toDateDisplay; // Use textContent to display the date

        // Alert or display the formatted date (for user visibility)
        // alert(toDateDisplay); // Uncomment if you want to show an alert

    } else if (type_of_pass == "halfyearly") {
        // Get the number of half-years from input
        const noOfHalfYears = parseInt(document.getElementById('no_of_days').value, 10) || 0; // Default to 0 if empty

        // Get the date input from the user
        const fromDateInput = document.getElementById('from_date').value;

        // Validate the input format for YYYY-MM-DD
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fromDateInput)) {
            alert("Please enter the date in YYYY-MM-DD format.");
            return;
        }

        // Create a new Date object directly from the input
        const fromDate = new Date(fromDateInput);

        // Check if the date is valid
        if (isNaN(fromDate.getTime())) {
            alert("Invalid date. Please check the input.");
            return;
        }

        // Get the current time
        const currentTime = new Date();
        const currentDate = new Date(currentTime); // Keep the current date

        // Set the hours and minutes to the current time
        fromDate.setHours(currentTime.getHours());
        fromDate.setMinutes(currentTime.getMinutes());

        // Add the number of half-years (6 months per half-year)
        fromDate.setMonth(fromDate.getMonth() + (noOfHalfYears * 6));

        // Format the date for storage (datetime-local)
        const year = fromDate.getFullYear();
        const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const day = String(fromDate.getDate()).padStart(2, '0');
        const hours = String(fromDate.getHours()).padStart(2, '0');
        const minutes = String(fromDate.getMinutes()).padStart(2, '0');

        // Combine for datetime-local storage
        const toDateStorage = `${year}-${month}-${day}T${hours}:${minutes}`;

        // Determine AM/PM format for display
        let displayHours = fromDate.getHours();
        const ampm = displayHours >= 12 ? 'PM' : 'AM';
        displayHours = displayHours % 12; // Convert to 12-hour format
        displayHours = displayHours ? String(displayHours).padStart(2, '0') : '12'; // Display '12' instead of '0'

        // Combine for display (with AM/PM)
        const toDateDisplay = `${year}-${month}-${day} ${displayHours}:${minutes} ${ampm}`;

        // Set the value of the to_date input for storage
        document.getElementById('to_date').value = toDateStorage;

        // Instead of alerting, append the formatted date to an HTML element
        const displayElement = document.getElementById('date_display'); // Ensure this element exists in your HTML
        displayElement.value = toDateDisplay; // Show current and calculated dates

    } else if (type_of_pass == "yearly") {

        // Get the number of years from input
        const noOfYears = parseInt(document.getElementById('no_of_days').value, 10) || 0; // Default to 0 if empty

        // Get the date input from the user or use the current date if not provided
        let fromDateInput = document.getElementById('from_date').value;

        // Use the current date if no input is provided
        if (!fromDateInput) {
            const currentDate = new Date();
            fromDateInput = currentDate.toISOString().split('T')[0]; // Format as YYYY-MM-DD
        }

        // Validate the input format for YYYY-MM-DD
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fromDateInput)) {
            alert("Please enter the date in YYYY-MM-DD format.");
            return;
        }

        // Create a new Date object directly from the input
        const fromDate = new Date(fromDateInput);

        // Check if the date is valid
        if (isNaN(fromDate.getTime())) {
            alert("Invalid date. Please check the input.");
            return;
        }

        // Get the current time for hours and minutes
        const currentTime = new Date();
        fromDate.setHours(currentTime.getHours());
        fromDate.setMinutes(currentTime.getMinutes());

        // Add the number of years
        fromDate.setFullYear(fromDate.getFullYear() + noOfYears);

        // Format the date for storage (datetime-local)
        const year = fromDate.getFullYear();
        const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const day = String(fromDate.getDate()).padStart(2, '0');
        const hours = String(fromDate.getHours()).padStart(2, '0');
        const minutes = String(fromDate.getMinutes()).padStart(2, '0');

        // Combine for datetime-local storage
        const toDateStorage = `${year}-${month}-${day}T${hours}:${minutes}`;

        // Determine AM/PM format for display
        let displayHours = fromDate.getHours();
        const ampm = displayHours >= 12 ? 'PM' : 'AM';
        displayHours = displayHours % 12; // Convert to 12-hour format
        displayHours = displayHours ? String(displayHours).padStart(2, '0') : '12'; // Display '12' instead of '0'

        // Combine for display (with AM/PM)
        const toDateDisplay = `${year}-${month}-${day} ${displayHours}:${minutes} ${ampm}`;

        // Set the value of the to_date input for storage
        document.getElementById('to_date').value = toDateStorage;

        // Append the formatted date to the date_display input
        const displayElement = document.getElementById('date_display'); // Ensure this element exists in your HTML
        displayElement.value = toDateDisplay; // Use textContent to display the date

    }

}


// }

window.onload = function() {
    document.getElementById('calculate_button').onclick = calculateToDate;
};


function get_vec_pass() {
    const noOfDays = parseInt(document.getElementById('no_of_days').value);
    const type_of_pass = document.getElementById('type_of_pass').value;
    const amount = document.getElementById('amount').value;
    if (type_of_pass != "")
        document.getElementById('no_of_days').value = "";
    document.getElementById('amount').value = "";
    document.getElementById('to_date').value = "";

}
</script>


@endsection