<?php

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

if (!function_exists('unique_id')) {
    function unique_id($prefix = "")
    {
        $unique_id = uniqid() . rand(100, 999);

        if ($prefix) {
            $unique_id = $prefix . $unique_id;
        }

        return $unique_id;
    }
}

function formatDate($dateString, $format = 'Y-m-d')
{
    $date = new DateTime($dateString);
    return $date->format($format);
}//Acc Year
function acc_year()
{
    $acc_year = '';
    $curr_year = date("Y");

    $today = strtotime(date("d-m-Y"));
    $end_date = strtotime("31-03-" . $curr_year);
    $start_date = strtotime("01-04-" . $curr_year);

    if ($today >= $start_date) {
        $next_year = $curr_year + 1;
        $acc_year = $curr_year . "-" . $next_year;
    } else if ($today <= $end_date) {
        $previous_year = $curr_year - 1;
        $acc_year = $previous_year . "-" . $curr_year;
    }

    return $acc_year;
}
// Uniqui ID Geneartor
function unique_id($prefix = "")
{

    $unique_id = uniqid() . rand(10000, 99999);

    if ($prefix) {
        $unique_id = $prefix . $unique_id;
    }

    return $unique_id;
}

// Convert Original folder Name to Display Name
function disname($name = "")
{
    if ($name) {
        $name = explode("_", $name);
        $name = array_map("ucfirst", $name);
        $name = implode(" ", $name);

        return $name;
    } else {
        return "Empty Title";
    }
}


//  function btn_update($route_name, $unique_id, $folder_name = "", $prefix = "", $suffix = "")
// {
//     $editUrl = route($route_name, ['unique_id' => $unique_id]);

//     // Generate the final string with the constructed URL
//     // class="btn btn-primary btn-action mr-1"
//     $final_str = '<a href="' . $editUrl . '"><i class="bx bxs-edit"></i></a>';

//     return $final_str;
// }

function btn_update($route_name, $unique_id, $folder_name = "", $prefix = "", $suffix = "")
{
    // Modify the URL structure to include the unique ID before the edit segment
    $editUrl = route($route_name, ['unique_id' => $unique_id]);

    // Generate the final string with the constructed URL
    // class="btn btn-primary btn-action mr-1"
    $final_str = '<a href="' . $editUrl . '"><i class="bx bxs-edit"></i></a>';

    return $final_str;
}

function btn_delete($route_name, $unique_id, $folder_name = "", $prefix = "", $suffix = "")
{
    $deleteUrl = route($route_name, ['unique_id' => $unique_id]);

    // Generate the final string with the constructed URL
    // class="btn btn-primary btn-action mr-1"
    $final_str = '<a href="' . $deleteUrl . '"><i class="bx bx-trash"></i></a>';

    return $final_str;
}



function get_zone($unique_id = "")
{

    $zone_names = DB::table('zones')->select("unique_id", "zone")->where(["is_active" => 1, "is_delete" => 0])->orderBy('id', 'ASC')->get();

    // print_r($zone_names);
// die();
    if ($zone_names) {
        return $zone_names;
    } else {
        print_r($zone_names);
        return 0;
    }
}

function taluk_names($unique_id = "")
{

    $taluk_names = DB::table('taluk_creation')->select("unique_id", "taluk_name")->where(["is_active" => 1, "is_delete" => 0])->where('unique_id', '<>', '641828393e9b989808')->where('unique_id', '<>', '641827f68916470107')->where('unique_id', '<>', '641827b4f11e514254')->where('unique_id', '<>', '6418277e41dbc55270')->where('unique_id', '<>', '6418280fc395690980')->orderBy('id', 'ASC')->get();

    if ($taluk_names) {
        return $taluk_names;
    } else {
        print_r($taluk_names);
        return 0;
    }
}

function get_district($unique_id = "")
{

    $district = DB::table('district')->select("unique_id", "district")->where(["is_active" => 1, "is_delete" => 0])->orderBy('id', 'ASC')->get();

    if ($district) {
        return $district;
    } else {
        print_r($district);
        return 0;
    }
}
function get_punch_category(){
    $category = DB::table('biometric_attendance')->select("verify_mode")->where([])->orderBy('id','ASC')->get();
    
    if($category){
        return $category;    
    }
    else{
        print_r($category);
        return 0;
    }
}