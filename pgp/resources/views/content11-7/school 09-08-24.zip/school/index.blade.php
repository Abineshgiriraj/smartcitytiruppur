@extends('layouts/contentNavbarLayout')

@section('title', 'Tables - Basic Tables')

@section('content')
<div class="row mb-3 page-hed">
    <div class="col-sm-6">
        <h4 class=""><span class="text-muted fw-light">Entry Form /</span> School</h4>
    </div>
    <div class="col-sm-6">
        <button class="btn btn-primary btn-right" onclick="window.location.href='{{ route('school.create') }}'" type="button">
            <i class="i-Add"></i> Add New
        </button>
    </div>
</div>

<!-- Responsive Datatable -->
<div class="card">
    <div class="card-body">
    <div class="card-datatable table-responsive">
    <table class="table table-bordered yajra-datatable">
    <thead>
        <tr>
            <th>No</th>
            <th>Zone</th>
            <th>District</th>
            <th>Taluk</th>
            <th>School</th>
            <th>Remarks</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>

    </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>

<script type="text/javascript">
  const districtMap = {
    '6b1c3a9f5e7d4028': 'Chennai',
    '5c9a2f7d3b4e1068': 'Salem',
    '0a5c9d4f6b7e8013': 'Erode'
};

const zoneMap = {
    '4e2d6f9b7a1c3058': 'Madhavaram',
    '8b7e1c3f5d9a6042': 'Tondiarpet',
    '2a8c4b6d9e1f3057': 'Royapuram'
};
const talukMap = {
    '9e3d1b5f7a4c6028': 'Taluk 1',
    '1b6f9a4d3c2e7058': 'Taluk 2'
};
  $(function () {
    var table = $('.yajra-datatable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('school.index') }}",
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
            // {data: 'district_name', name: 'district_name'},
            // {data: 'zone_name', name: 'zone_name'},
            {
                data: 'district_name',
                name: 'district_name',
                render: function(data, type, row) {
                    return districtMap[data] || data; // Default to data if no match
                }
            },
            {
                data: 'zone_name',
                name: 'zone_name',
                render: function(data, type, row) {
                    return zoneMap[data] || data; // Default to data if no match
                }
            },
            {
                data: 'taluk_name',
                name: 'taluk_name',
                render: function(data, type, row) {
                    return talukMap[data] || data; // Default to data if no match
                }
            },
            {data: 'school_name', name: 'school_name'},
            {data: 'remark', name: 'remark'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
  });
</script>


@endsection
