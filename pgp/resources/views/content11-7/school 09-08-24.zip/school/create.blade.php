@extends('layouts/contentNavbarLayout')

@section('title', 'School Form')

@section('content')

<div class="row mb-3 page-hed">
    <div class="col-12">
        <h4>
            <span class="text-muted fw-light">Entry Form /</span> School {{ isset($school) ? 'Edit' : 'Creation' }}
        </h4>
    </div>
</div>

<style>
/* btn style */
.btn-right {
    float: right;
}
</style>

<!-- Basic Layout -->
<div class="row">
    <div class="col-xl">
        <div class="card mb-4">
            <div class="card-body">
                <form id="schoolForm" method="POST"
                    action="{{ isset($school) ? route('school.update', $school->id) : route('school.store') }}">
                    @csrf
                    @if(isset($school))
                    @method('PUT')
                    <input type="hidden" name="id" value="{{ $school->id }}">
                    @endif

                    <div class="row mb-3">
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="district_name">District Name</label>
                            <select class="form-select" id="district_name" name="district_name">
                                <option value="">Select District</option>
                                <option value="6b1c3a9f5e7d40">
                                    Chennai</option>
                                <option value=" 5c9a2f7d3b4e1068"
                                    {{ isset($school) && $school->district_name === '5c9a2f7d3b4e1068' ? 'selected' : '' }}>
                                    Salem</option>
                                <option value="0a5c9d4f6b7e8013"
                                    {{ isset($school) && $school->district_name === '0a5c9d4f6b7e8013' ? 'selected' : '' }}>
                                    Erode</option>
                                <!-- Add more options as needed -->
                            </select>
                            <span id="district_nameError" class="text-danger"></span>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="zone_name">Zone Name</label>
                            <select class="form-select" id="zone_name" name="zone_name">
                                <option value="">Select Zone</option>
                                <option value="4e2d6f9b7a1c3058"
                                    {{ isset($school) && $school->zone_name === '4e2d6f9b7a1c3058' ? 'selected' : '' }}>
                                    Madhavaram</option>
                                <option value="8b7e1c3f5d9a6042"
                                    {{ isset($school) && $school->zone_name === '8b7e1c3f5d9a6042' ? 'selected' : '' }}>
                                    Tondiarpet</option>
                                <option value="2a8c4b6d9e1f3057"
                                    {{ isset($school) && $school->zone_name === '2a8c4b6d9e1f3057' ? 'selected' : '' }}>
                                    Royapuram</option>
                                <!-- Add more options as needed -->
                            </select>
                            <span id="zone_nameError" class="text-danger"></span>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="taluk_name">Taluk Name</label>
                            <select class="form-select" id="taluk_name" name="taluk_name">
                                <option value="">Select Taluk</option>
                                <option value="9e3d1b5f7a4c6028"
                                    {{ isset($school) && $school->taluk_name === '9e3d1b5f7a4c6028' ? 'selected' : '' }}>
                                    Taluk 1</option>
                                <option value="1b6f9a4d3c2e7058"
                                    {{ isset($school) && $school->taluk_name === '1b6f9a4d3c2e7058' ? 'selected' : '' }}>
                                    Taluk 2</option>
                                <!-- Add more options as needed -->
                            </select>
                            <span id="taluk_nameError" class="text-danger"></span>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="school_name">School (or) Location Name</label>
                            <input type="text" class="form-control" id="school_name" name="school_name"
                                value="{{ $school->school_name ?? '' }}" />
                            <span id="school_nameError" class="text-danger"></span>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="remark">Remarks</label>
                            <textarea class="form-control" id="remark"
                                name="remark">{{ $school->remark ?? '' }}</textarea>
                            <!-- <span id="remarkError" class="text-danger"></span> -->
                        </div>
                    </div>
                    <div class="btn-float">
                        <button class="btn btn-danger" type="button"
                            onclick="window.location.href='{{ route('school.index') }}'">Cancel</button>
                        <button type="submit"
                            class="btn btn-primary">{{ isset($school) ? 'Update' : 'Submit' }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection


<!-- <script>
function submitForm(event) {
    event.preventDefault();

    let isValid = validateForm();
    if (!isValid) {
        return false;
    }

    let formData = {
        district_name: $('#district_name').val(),
        zone_name: $('#zone_name').val(),
        taluk_name: $('#taluk_name').val(),
        school_name: $('#school_name').val(),
        remark: $('#remark').val(),
        _token: '{{ csrf_token() }}',
        _method: '{{ isset($school) ? '
        PUT ' : '
        POST ' }}'
    };

    // Determine URL based on whether it's an update or create operation
    let url = '{{ isset($school) ? url("school/" . $school->id . "/update") : url("school/store") }}';

    $.ajax({
        url: url,
        method: 'POST', // Always use POST, Laravel will handle the method type through _method
        data: formData,
        success: function(response) {
            alert('School ' + (formData._method === 'POST' ? 'created' : 'updated') + ' successfully!');
            window.location.href = "{{ url('school') }}";
        },
        error: function(xhr) {
            let errors = xhr.responseJSON.errors;
            for (let field in errors) {
                $(`#${field}Error`).text(errors[field][0]);
            }
        }
    });

    return false;
}

function validateForm() {
    let isValid = true;

    // Clear previous error messages
    $('.text-danger').text('');

    // Validation logic
    $('#district_name').each(function() {
        if ($(this).val().trim() === '') {
            $('#district_nameError').text('District Name is required.');
            isValid = false;
        }
    });

    $('#zone_name').each(function() {
        if ($(this).val().trim() === '') {
            $('#zone_nameError').text('Zone Name is required.');
            isValid = false;
        }
    });

    $('#taluk_name').each(function() {
        if ($(this).val().trim() === '') {
            $('#taluk_nameError').text('Taluk Name is required.');
            isValid = false;
        }
    });

    $('#school_name').each(function() {
        if ($(this).val().trim() === '') {
            $('#school_nameError').text('School Name is required.');
            isValid = false;
        }
    });

    return isValid;
}
</script> -->

<script>
function submitForm(event) {
    event.preventDefault();

    let isValid = validateForm();
    if (!isValid) {
        return false;
    }

    let formData = {
        district_name: $('#district_name').val(),
        zone_name: $('#zone_name').val(),
        taluk_name: $('#taluk_name').val(),
        school_name: $('#school_name').val(),
        remark: $('#remark').val(),
        _token: '{{ csrf_token() }}',
        _method: '{{ isset($school) ? '
        PUT ' : '
        POST ' }}'
    };

    // Determine URL based on whether it's an update or create operation
    let url = '{{ isset($school) ? url("school/" . $school->id . "/update") : url("school/store") }}';

    $.ajax({
        url: url,
        method: 'POST', // Always use POST, Laravel will handle the method type through _method
        data: formData,
        success: function(response) {
            alert('School ' + (formData._method === 'POST' ? 'created' : 'updated') + ' successfully!');
            window.location.href = "{{ url('school') }}";
        },
        error: function(xhr) {
            let errors = xhr.responseJSON.errors;
            for (let field in errors) {
                $(`#${field}Error`).text(errors[field][0]);
            }
        }
    });

    return false;
}

function validateForm() {
    let isValid = true;

    // Clear previous error messages
    $('.text-danger').text('');

    // Validation logic
    if ($('#district_name').val().trim() === '') {
        $('#district_nameError').text('District Name is required.');
        isValid = false;
    }

    if ($('#zone_name').val().trim() === '') {
        alert('ij');
        $('#zone_nameError').text('Zone Name is required.');
        isValid = false;
    }

    if ($('#taluk_name').val().trim() === '') {
        $('#taluk_nameError').text('Taluk Name is required.');
        isValid = false;
    }

    if ($('#school_name').val().trim() === '') {
        $('#school_nameError').text('School Name is required.');
        isValid = false;
    }

    return isValid;
}
</script>