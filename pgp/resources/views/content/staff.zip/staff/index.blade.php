@extends('layouts/contentNavbarLayout')

@section('title', 'Tables - Basic Tables')

<style>
/* btn style */
.btn-right {
    float: right;
}
</style>

@section('content')

<div class="row mb-3 page-hed">
    <div class="col-sm-6">
        <h4>
            <span class="text-muted fw-light">Entry Form /</span> Staff Creation
        </h4>
    </div>
    <div class="col-sm-6">
        <button class="btn btn-primary btn-right" onclick="window.location.href='{{ route('staff.create') }}'"
            type="button">
            <i class="i-Add"></i> Add New
        </button>
    </div>
</div>

<!-- Responsive Datatable -->
<div class="card">
    <div class="card-body">
        <div class="card-datatable table-responsive">
            <table class="dt-responsive table border-top" id="example">
                <thead>
                    <tr>
                        <th>Emp name</th>
                        <th>Emp id</th>
                        <th>Designation</th>
                        <th>District</th>
                        <th>Zone</th>
                        <th>School</th>
                        <th>Date of Join</th>
                        <th>Mobile number</th>
                        <th>Actions</th> <!-- Add Actions Column -->
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!--/ Responsive Datatable -->

<!-- Include necessary CSS files -->
<link rel="stylesheet" href="{{ asset('public/assets/css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{ asset('public/assets/css/dataTables.bootstrap5.css') }}" />
<link rel="stylesheet" href="{{ asset('public/assets/css/responsive.bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{ asset('public/assets/css/core.css') }}" />

<!-- Include necessary JS files -->
<script src="{{ asset('public/assets/js/jquery-3.7.1.js') }}"></script>
<script src="{{ asset('public/assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('public/assets/js/dataTables.js') }}"></script>
<script src="{{ asset('public/assets/js/dataTables.bootstrap5.js') }}"></script>
<script src="{{ asset('public/assets/js/dataTables.responsive.js') }}"></script>
<script src="{{ asset('public/assets/js/responsive.bootstrap5.js') }}"></script>

<script type="text/javascript">
const designationMap = {
    '8f0d5b3c0f4a321a': 'Accountant',
    '1a6d3f2e5c7890b1': 'Clerk',
    '7b2e6c8a9d1f4732': 'Teacher'
};

const districtMap = {
    '4c7f8b2d6a3e9051': 'Chennai',
    '2e5f9d7a4b6c1038': 'Salem',
    '3b9f6a8d5c1e7204': 'Erode',
    '6d4f1a2e8b9c3057': 'Namakkal',
    '0e2c4d6a9b5f8713': 'Coimbatore',
    '5a7d8f2c1e6b4039': 'Karur'
};

const zoneMap = {
    '9c6b3f8d1a5e7024': 'Madhavaram',
    '3c5f7a1e6d9b8042': 'Tondiarpet',
    '7d2e1f5b4c6a9038': 'Royapuram',
    '1b6f9a4d3c2e7058': 'Thiruvottiyur',
    '9e3d1b5f7a4c6028': 'Manali'
};
const schoolMap = {
    '2a8c4b6d9e1f3057': 'Govt. Boys School',
    '8b7e1c3f5d9a6042': 'Govt. Higher Sec. School'
};

// $(document).ready(function() {
//     $('#example').DataTable({
//         processing: true,
//         serverSide: true,
//         ajax: '{{ route('staff.index') }}',
//         columns: [

//             { data: 'emp_name', name: 'emp_name' },
//             { data: 'emp_id', name: 'emp_id' },
//             { data: 'designation', name: 'designation' },
//             { data: 'district', name: 'district' },
//             { data: 'zone', name: 'zone' },
//             { data: 'school', name: 'school' },
//             { data: 'doj', name: 'doj' },
//             { data: 'emp_contact', name: 'emp_contact' },
//             { data: 'action', name: 'action', orderable: false, searchable: false } // Action column
//         ]
//     });

$(document).ready(function() {
    $('#example').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('staff.index') }}",
        columns: [{
                data: 'emp_name',
                name: 'emp_name'
            },
            {
                data: 'emp_id',
                name: 'emp_id'
            },
            {
                data: 'designation',
                name: 'designation',
                render: function(data, type, row) {
                    return designationMap[data] || data; // Default to data if no match
                }
            },
            {
                data: 'district',
                name: 'district',
                render: function(data, type, row) {
                    return districtMap[data] || data; // Default to data if no match
                }
            },
            {
                data: 'zone',
                name: 'zone',
                render: function(data, type, row) {
                    return zoneMap[data] || data; // Default to data if no match
                }
            },
            {
                data: 'school',
                name: 'school',
                render: function(data, type, row) {
                    return schoolMap[data] || data; // Default to data if no match
                }
            },
            // { data: 'school', name: 'school' },
            {
                data: 'doj',
                name: 'doj'
            },
            {
                data: 'emp_contact',
                name: 'emp_contact'
            },
            {
                data: 'action',
                name: 'action',
                orderable: false,
                searchable: false
            }
        ]
    });
});



// Handle delete button click

$(document).ready(function() {
    // Handle delete button click
    $(document).on('click', '.delete-btn', function() {
        var url = $(this).data('url');

        if (confirm('Are you sure you want to delete this record?')) {
            $.ajax({
                url: url,
                type: 'DELETE',
                data: {
                    _token: '{{ csrf_token() }}' // Ensure CSRF token is included
                },
                success: function(result) {
                    $('#example').DataTable().ajax.reload(); // Reload table data
                },
                error: function(xhr) {
                    console.error(xhr.responseText); // Log error for debugging
                    alert('An error occurred while deleting the record.');
                }
            });
        }
    });
});
</script>

@endsection