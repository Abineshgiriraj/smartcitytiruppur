@extends('layouts/contentNavbarLayout')

@section('title', 'Staff Form')

@section('content')
<div class="row mb-3 page-hed">
    <div class="col-12">
        <h4>
            <span class="text-muted fw-light">Entry Form /</span> Staff {{ isset($staff) ? 'Edit' : 'Creation' }}
        </h4>
    </div>
</div>

<style>
/* btn style */
.btn-right {
    float: right;
}
</style>

<!-- Basic Layout -->
<div class="row">
    <div class="col-xl">
        <div class="card mb-4">
            <div class="card-body">
                <form id="staffForm" method="post" onsubmit="return submitForm(event);">
                    @csrf
                    @if(isset($staff))
                    @method('PUT')
                    <input type="hidden" name="id" value="{{ $staff->id }}">
                    @endif
                    <div class="row mb-3">
                        <!-- Academic Year -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="acc_year">Academic Year</label>
                            <select class="form-select" id="acc_year" name="acc_year">
                                <option value="">Select Academic Year</option>
                                <option value="1" {{ isset($staff) && $staff->acc_year == '1' ? 'selected' : '' }}>
                                    2024-2025</option>
                                <option value="2" {{ isset($staff) && $staff->acc_year == '2' ? 'selected' : '' }}>
                                    2025-2026</option>
                            </select>
                            <span id="emp_idError" class="text-danger"></span>
                        </div>
                        <!-- Employee Name -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="emp_name">Employee Name</label>
                            <input type="text" class="form-control" id="emp_name" name="emp_name"
                                value="{{ $staff->emp_name ?? '' }}" />
                            <span id="emp_nameError" class="text-danger"></span>
                        </div>
                        <!-- Employee ID -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="emp_id">Employee ID</label>
                            <input type="text" class="form-control" id="emp_id" name="emp_id"
                                value="{{ $staff->emp_id ?? '' }}" />
                            <span id="emp_idError" class="text-danger"></span>
                        </div>
                        <!-- Designation -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="designation">Designation</label>
                            <select class="form-select" id="designation" name="designation">
                                <option value="">Select Designation</option>
                                <option value="8f0d5b3c0f4a321a"
                                    {{ isset($staff) && $staff->designation == '8f0d5b3c0f4a321a' ? 'selected' : '' }}>
                                    Accountant</option>
                                <option value="1a6d3f2e5c7890b1"
                                    {{ isset($staff) && $staff->designation == '1a6d3f2e5c7890b1' ? 'selected' : '' }}>
                                    Clerk</option>
                                <option value="7b2e6c8a9d1f4732"
                                    {{ isset($staff) && $staff->designation == '7b2e6c8a9d1f4732' ? 'selected' : '' }}>
                                    Teacher</option>
                            </select>
                            <span id="designationError" class="text-danger"></span>
                        </div>
                        <!-- Zone -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="zone">Zone Name</label>
                            <select class="form-select select2" id="zone" name="zone">
                                <option value="">Select Zone</option>
                                <option value="9c6b3f8d1a5e7024"
                                    {{ isset($staff) && $staff->zone == '9c6b3f8d1a5e7024' ? 'selected' : '' }}>
                                    Madhavaram</option>
                                <option value="3c5f7a1e6d9b8042"
                                    {{ isset($staff) && $staff->zone == '3c5f7a1e6d9b8042' ? 'selected' : '' }}>
                                    Tondiarpet</option>
                                <option value="7d2e1f5b4c6a9038"
                                    {{ isset($staff) && $staff->zone == '7d2e1f5b4c6a9038' ? 'selected' : '' }}>
                                    Royapuram</option>
                                <option value="1b6f9a4d3c2e7058"
                                    {{ isset($staff) && $staff->zone == '1b6f9a4d3c2e7058' ? 'selected' : '' }}>
                                    Thiruvottiyur</option>
                                <option value="9e3d1b5f7a4c6028"
                                    {{ isset($staff) && $staff->zone == '9e3d1b5f7a4c6028' ? 'selected' : '' }}>Manali
                                </option>
                            </select>
                            <span id="zoneError" class="text-danger"></span>
                        </div>
                        <!-- District -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="district">District Name</label>
                            <select class="form-select" id="district" name="district">
                                <option value="">Select District</option>
                                <option value="4c7f8b2d6a3e9051"
                                    {{ isset($staff) && $staff->district == '4c7f8b2d6a3e9051' ? 'selected' : '' }}>
                                    Chennai</option>
                                <option value="2e5f9d7a4b6c1038"
                                    {{ isset($staff) && $staff->district == '2e5f9d7a4b6c1038' ? 'selected' : '' }}>
                                    Salem</option>
                                <option value="3b9f6a8d5c1e7204"
                                    {{ isset($staff) && $staff->district == '3b9f6a8d5c1e7204' ? 'selected' : '' }}>
                                    Erode</option>
                                <option value="6d4f1a2e8b9c3057"
                                    {{ isset($staff) && $staff->district == '6d4f1a2e8b9c3057' ? 'selected' : '' }}>
                                    Namakkal</option>
                                <option value="0e2c4d6a9b5f8713"
                                    {{ isset($staff) && $staff->district == '0e2c4d6a9b5f8713' ? 'selected' : '' }}>
                                    Coimbatore</option>
                                <option value="5a7d8f2c1e6b4039"
                                    {{ isset($staff) && $staff->district == '5a7d8f2c1e6b4039' ? 'selected' : '' }}>
                                    Karur</option>
                            </select>
                            <span id="districtError" class="text-danger"></span>
                        </div>
                        <!-- Taluk -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="taluk_name">Taluk Name</label>
                            <select class="form-select" id="taluk_name" name="taluk_name">
                                <option value="">Select Taluk</option>
                                <option value="9e3d1b5f7a4c6028"
                                    {{ isset($staff) && $staff->taluk_name == '9e3d1b5f7a4c6028' ? 'selected' : '' }}>
                                    Taluk 1</option>
                                <option value="1b6f9a4d3c2e7058"
                                    {{ isset($staff) && $staff->taluk_name == '1b6f9a4d3c2e7058' ? 'selected' : '' }}>
                                    Taluk 2</option>
                                <!-- Add more options as needed -->
                            </select>
                            <span id="taluk_nameError" class="text-danger"></span>
                        </div>
                        <!-- School -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="school">School (or) Location Name</label>
                            <select class="form-select select2" id="school" name="school">
                                <option value="">Select School</option>
                                <option value="2a8c4b6d9e1f3057"
                                    {{ isset($staff) && $staff->school == '2a8c4b6d9e1f3057' ? 'selected' : '' }}>Govt.
                                    Boys School</option>
                                <option value="8b7e1c3f5d9a6042"
                                    {{ isset($staff) && $staff->school == '8b7e1c3f5d9a6042' ? 'selected' : '' }}>Govt.
                                    Higher Sec. School</option>
                            </select>
                            <span id="schoolError" class="text-danger"></span>
                        </div>
                        <!-- Date of Join -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="doj">Date of Join</label>
                            <input type="date" class="form-control" id="doj" name="doj"
                                value="{{ $staff->doj ?? '' }}" />
                            <span id="dojError" class="text-danger"></span>
                        </div>
                        <!-- Employee Contact Number -->
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="emp_contact">Employee Contact Number</label>
                            <input type="text" class="form-control" id="emp_contact" name="emp_contact"
                                value="{{ $staff->emp_contact ?? '' }}" />
                            <span id="emp_contactError" class="text-danger"></span>
                        </div>
                    </div>
                    <div class="btn-float">
                        <!-- <button class="btn btn-danger" type="button"
                            onclick="window.location.href='{{ url('/staff') }}'">Cancel</button>
                        <button type="submit" class="btn btn-primary">{{ isset($staff) ? 'Update' : 'Submit' }}</button>
                    </div>
                </form> -->
                        <button class="btn btn-danger" type="button"
                            onclick="window.location.href='{{ url('/staff') }}'">Cancel</button>
                        <button type="submit" class="btn btn-primary">{{ isset($staff) ? 'Update' : 'Submit' }}</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

<!-- <script>
function submitForm(event) {
    event.preventDefault();

    let isValid = validateForm();
    if (!isValid) {
        return false;
    }

    let formData = {
        acc_year: $('#acc_year').val(),
        emp_name: $('#emp_name').val(),
        emp_id: $('#emp_id').val(),
        designation: $('#designation').val(),
        district: $('#district').val(),
        zone: $('#zone').val(),
        taluk_name: $('#taluk_name').val(),
        school: $('#school').val(),
        doj: $('#doj').val(),
        emp_contact: $('#emp_contact').val(),
        _token: '{{ csrf_token() }}',
        _method: '{{ isset($staff) ? '
        PUT ' : '
        POST ' }}'
    };

    let url = '{{ isset($staff) ? url("staff/" . $staff->id . "/update") : url("staff/store") }}';


    $.ajax({
        url: url,
        method: 'POST', // Ensure method is POST for PUT/PATCH requests
        data: formData,
        success: function(response) {
            alert('Staff ' + (formData._method === 'POST' ? 'created' : 'updated') + ' successfully!');
            window.location.href = "{{ url('/staff') }}";
        },
        error: function(xhr) {
            let errors = xhr.responseJSON.errors;
            for (let field in errors) {
                $(`#${field}Error`).text(errors[field][0]);
            }
        }
    });

    return false;
}

function validateForm() {
    let isValid = true;
    let emp_contactInput = document.getElementById('emp_contact');

    // Clear previous error messages
    $('.text-danger').text('');

    // Validation logic
    $('#emp_name').each(function() {
        if ($(this).val().trim() === '') {
            $('#emp_nameError').text('Employee Name is required.');
            isValid = false;
        }
    });

    $('#emp_id').each(function() {
        if ($(this).val().trim() === '') {
            $('#emp_idError').text('Employee ID is required.');
            isValid = false;
        }
    });

    $('#acc_year').each(function() {
        if ($(this).val().trim() === '') {
            $('#acc_yearError').text('Academic year is required.');
            isValid = false;
        }
    });

    $('#designation').each(function() {
        if ($(this).val().trim() === '') {
            $('#designationError').text('Designation is required.');
            isValid = false;
        }
    });

    $('#district').each(function() {
        if ($(this).val().trim() === '') {
            $('#districtError').text('District is required.');
            isValid = false;
        }
    });

    $('#zone').each(function() {
        if ($(this).val().trim() === '') {
            $('#zoneError').text('Zone is required.');
            isValid = false;
        }
    });

    $('#school').each(function() {
        if ($(this).val().trim() === '') {
            $('#schoolError').text('School is required.');
            isValid = false;
        }
    });

    $('#doj').each(function() {
        if ($(this).val().trim() === '') {
            $('#dojError').text('Date of join is required.');
            isValid = false;
        }
    });

    $('#emp_contact').each(function() {
        if ($(this).val().trim() === '') {
            $('#emp_contactError').text('Employee contact is required.');
            isValid = false;
        } else if (emp_contactInput.value.length > 10 || emp_contactInput.value.length < 10) {
            $('#emp_contactError').text('Mobile Number must be 10 characters.');
            isValid = false;
        } else if (!/^[0-9]+$/.test(emp_contactInput.value.trim())) {
            $('#emp_contactError').text('Mobile Number must contain only numeric characters.');
            isValid = false;
        }
    });

    // Additional validation logic as required

    return isValid;
}
</script> -->
<script>
function submitForm(event) {
    event.preventDefault();

    let isValid = validateForm();
    if (!isValid) {
        return false;
    }

    let formData = {
        acc_year: $('#acc_year').val(),
        emp_name: $('#emp_name').val(),
        emp_id: $('#emp_id').val(),
        designation: $('#designation').val(),
        district: $('#district').val(),
        zone: $('#zone').val(),
        taluk_name: $('#taluk_name').val(),
        school: $('#school').val(),
        doj: $('#doj').val(),
        emp_contact: $('#emp_contact').val(),
        _token: '{{ csrf_token() }}',
        _method: '{{ isset($staff) ? '
        PUT ' : '
        POST ' }}'
    };

    let url = '{{ isset($staff) ? url("staff/" . $staff->id) : url("staff") }}';

    $.ajax({
        url: url,
        method: 'POST',
        data: formData,
        success: function(response) {
            alert('Staff ' + (formData._method === 'POST' ? 'created' : 'updated') + ' successfully!');
            window.location.href = "{{ url('/staff') }}";
        },
        error: function(xhr) {
            let errors = xhr.responseJSON.errors;
            for (let field in errors) {
                $(`#${field}Error`).text(errors[field][0]);
            }
        }
    });

    return false;
}
</script>

<!-- <script>
    function submitForm(event) {
    event.preventDefault();

    let isValid = validateForm();
    if (!isValid) {
    return false;
    }

    let formData = {
    acc_year: $('#acc_year').val(),
    emp_name: $('#emp_name').val(),
    emp_id: $('#emp_id').val(),
    designation: $('#designation').val(),
    district: $('#district').val(),
    zone: $('#zone').val(),
    taluk_name: $('#taluk_name').val(),
    school: $('#school').val(),
    doj: $('#doj').val(),
    emp_contact: $('#emp_contact').val(),
    _token: '{{ csrf_token() }}',
    _method: '{{ isset($staff) ? '
        PUT ' : '
        POST ' }}'
    };

    let url = '{{ isset($staff) ? url("staff/" . $staff->id) : url("staff") }}'; // Adjusted URL

    $.ajax({
    url: url,
    method: 'POST', // Always use POST for AJAX; Laravel will handle the method via _method
    data: formData,
    success: function(response) {
    alert('Staff ' + (formData._method === 'POST' ? 'created' : 'updated') + ' successfully!');
    window.location.href = "{{ url('/staff') }}";
    },
    error: function(xhr) {
    let errors = xhr.responseJSON.errors;
    for (let field in errors) {
    $(`#${field}Error`).text(errors[field][0]);
    }
    }
    });

    return false;
    }

    function validateForm() {
    let isValid = true;
    let emp_contactInput = document.getElementById('emp_contact');

    // Clear previous error messages
    $('.text-danger').text('');

    // Validation logic
    if ($('#emp_name').val().trim() === '') {
    $('#emp_nameError').text('Employee Name is required.');
    isValid = false;
    }

    if ($('#emp_id').val().trim() === '') {
    $('#emp_idError').text('Employee ID is required.');
    isValid = false;
    }

    if ($('#acc_year').val().trim() === '') {
    $('#acc_yearError').text('Academic year is required.');
    isValid = false;
    }

    if ($('#designation').val().trim() === '') {
    $('#designationError').text('Designation is required.');
    isValid = false;
    }

    if ($('#district').val().trim() === '') {
    $('#districtError').text('District is required.');
    isValid = false;
    }

    if ($('#zone').val().trim() === '') {
    $('#zoneError').text('Zone is required.');
    isValid = false;
    }

    if ($('#school').val().trim() === '') {
    $('#schoolError').text('School is required.');
    isValid = false;
    }

    if ($('#doj').val().trim() === '') {
    $('#dojError').text('Date of join is required.');
    isValid = false;
    }

    if ($('#emp_contact').val().trim() === '') {
    $('#emp_contactError').text('Employee contact is required.');
    isValid = false;
    } else if (emp_contactInput.value.length !== 10) {
    $('#emp_contactError').text('Mobile Number must be 10 characters.');
    isValid = false;
    } else if (!/^[0-9]+$/.test(emp_contactInput.value.trim())) {
    $('#emp_contactError').text('Mobile Number must contain only numeric characters.');
    isValid = false;
    }

    return isValid;
    }
    </script> -->